
import java.util.ArrayList;
import java.util.List;
public class Invoice {
    private double subtotal;
    private double vat;
    private double total;
    private List<Produkti>products;
    private int firstQuanity;

    public Invoice(){
        products = new ArrayList<>();
        firstQuanity =0;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }

    public double getVat() {
        return vat;
    }

    public void setVat(double vat) {
        this.vat = vat;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public List<Produkti> getProducts() {
        return products;
    }

  public void addItem (Produkti produkti){
        if(firstQuanity + produkti.getQty()>50){
            firstQuanity = 0;
        }
        products.add(produkti);
        firstQuanity += produkti.getQty();
  }
}
