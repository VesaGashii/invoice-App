public class Produkti {
    private String name;
    private int qty;
    private double price;
    private int vat;
    private double discount;

    public Produkti(String name, int qty, double price, int vat, double discount) {
        this.name = name;
        this.qty = qty;
        this.price = price;
        this.vat = vat;
        this.discount = discount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getVat() {
        return vat;
    }

    public void setVat(int vat) {
        this.vat = vat;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }
}
