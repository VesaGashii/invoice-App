import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jdk.jfr.Threshold;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.io.File;
import java.io.IOException;
import java.util.List;

@Controller
public class InvoiceController {
    @Autowired
    private InvoiceService invoiceService;
    private static final int THRESHOLD_ITEM = 50;
@GetMapping("/invoices")
    public String putProduktet(Model shembulli){
    try{
        ObjectMapper readfajllin = new ObjectMapper();
        List<Produkti> products = readfajllin.readValue(new File("products.json"), new TypeReference<List<Produkti>>() {});
        List<Invoice> invoices = invoiceService.invoiceSeparate(products, THRESHOLD_ITEM);

        shembulli.addAttribute("invoices", invoices);
        return "table_format";
    }catch (IOException v){
        return "error";
    }

    }


}
