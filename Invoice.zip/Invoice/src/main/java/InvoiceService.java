import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class InvoiceService {

    public double subTotalCalc(List<Produkti> products){
        double subtotal = 0.0;
        for(Produkti produkti: products){
            double cmimi = produkti.getPrice()*produkti.getQty();
            double discount = produkti.getQty()* produkti.getDiscount();
            subtotal += cmimi-discount;
        }
        return subtotal;
    }

    public double vatCalc(List<Produkti> products){
        double vat = 0.0;
        for(Produkti produkti:products){
            double v = (produkti.getPrice() * produkti.getQty() * produkti.getVat())/100.0;
            vat+=v;
        }
        return vat;
    }

    public double totalCalc(List<Produkti>products){
        double total = subTotalCalc(products) + vatCalc(products);
        return total;
    }

    private static final int THRESHOLD_ITEM = 50;
    private void invoiceDone(Invoice invoice, double subtotal){
        invoice.setSubtotal(subtotal);
    }
    public List <Invoice>invoiceSeparate(List<Produkti>products, int thresholdItem){
        List<Invoice> invoices = new ArrayList<>();
        Invoice firstInvoice = new Invoice();
        double firstSubtotal = 0.0;
        int firstQuanity = 0;

        for(Produkti produkti: products){
            double totalItem = totalCalc(List.of(produkti));
            firstQuanity += produkti.getQty();

            if(firstQuanity> THRESHOLD_ITEM){
                invoiceDone(firstInvoice, firstSubtotal);
                invoices.add(firstInvoice);
                firstInvoice = new Invoice();
                firstSubtotal = 0.0;
                firstQuanity = 0;
            }
            firstSubtotal += totalItem;
            firstInvoice.addItem(produkti);
        }

        invoiceDone(firstInvoice, firstSubtotal);
        invoices.add(firstInvoice);
        return invoices;
    }


}
